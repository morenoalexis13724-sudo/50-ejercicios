class futbol:
    def __init__ (self, nombre,equipo,dorsal): 
        self.nombre=nombre
        self.equipo=equipo
        self.dorsal=dorsal
a1=futbol("cristiano","al nasar", "7")
print(a1.nombre, a1.equipo, a1.dorsal)