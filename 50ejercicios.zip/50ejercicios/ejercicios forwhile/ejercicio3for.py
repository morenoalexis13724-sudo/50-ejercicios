class mascotas:
 def __init__(self, razas, color, tamaño):
                 self.razas = razas
                 self.color = color
                 self.tamaño = tamaño
tipoderazas = mascotas("pug", "pitbull", "labrador" )
razas2 = ["bulldog","beagle","poodle","aleman"]
print("razas de perros en la lista:")
for raza in razas2:
        print("dueños",mascotas)