class empresas:
 def __init__(self, ubicacion, dueños, oficinas):
                 self.ubicacion  = ubicacion
                 self.dueños = dueños
                 self.oficinas = oficinas
mejoresempresas = empresas("camaro", "mercedez", "ferrari" )
empleados = ["juan","pedro","camilo","david"]
print("lista de los empleados:")
for empleado in empleados:
        print("dueños",empleados)
